<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Approvr </title>    
    <link href="https://fonts.googleapis.com/css2?family=Maven+Pro:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/reset.css">
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/modifiers.css">
    <link rel="stylesheet" href="../assets/css/forms.css">
</head>
    <body>
        <main>
            <section class="inline-block width-50 height-100 align-top background-color-brown">
             
            </section>            