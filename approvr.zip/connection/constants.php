<?php
define('CONNECTION_DETAILS', [
    'HOST' => 'localhost',
    'USER' => 'root',
    'PASS' => '',
    'DBNAME' => 'approver'
]);